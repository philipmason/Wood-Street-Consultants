code1.sas			code produced from wizard for making table from sashelp.orsales
code2.sas			simple stp to print a table from sashelp
code3.sas			added graph and print to code1.sas
code4.sas			added where clause with product_line
code5.sas			stp to generate form in html and call another stp
code6.sas			as above but with iframe to keep report on same page
code7.sas			as above but added extra fields to form
code8.sas			as above but with some extra macro vars to generalise
crossfilter1.html	Simple example from internet
crossfilter2.html	Converted to use sashelp.prdsale from csv2 stp
crossfilter3.html	Changed to use sashelp.orsales from csv2 stp and some minor mods
csv1.sas			stp to reporduce some csv data from a specific example
highdata.csv		data for highcharts example
highcharts1.html	simple example with csv file
highcharts2.html	switch data to use orsales, produced by PROC EXPORT
highcharts3.html	switch data to use stp feeding in orsales
html1.html			menu of stored processes to run
html2.html			as above but using a form
javascript1.html	showcase of javascript mouse functions
jqgrid1.html		grid using json file made by PROC 
jqgrid2.html		as above?
jqgrid3.html		switch the json to a stp
jquery1.html		simple jquery
jquery2.html		more simple jquery
jquery3.html		simple jquery loading content to page
json1.sas			produce some custom JSON via a data step
json2.sas			use PROC EXPORT to make some csv data
json3.sas			use PROC JSON to make some JSON
layout1.html		*** might not use
menu.html			load a div from a stp and use parms from a form
stream1.sas			data step to stream HTML to make pie/bar/row, inline csv
stream2.sas			stp using proc stream to make pie/bar/row, inline csv
stream3.sas			stp using proc stream to make pie/bar/row, csv from data step
stream4.sas			stp using proc stream to make pie/bar/row, csv from stp
sum_orsales.csv		CSV data for sashelp.orsales made using PROC EXPORT
