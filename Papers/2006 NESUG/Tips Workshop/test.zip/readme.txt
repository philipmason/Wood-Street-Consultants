Presentation: There is no presentation that goes with this paper since it will all be done as a series of guided demonstrations for participants to follow during the workshop.

Paper: available from the NESUG proceedings, covers the material presented in the workshop. This is the main reference.

Special Instructions: To run the sample code copy it into C:\workshop\hw06

Contact Information: phil@woodstreet.org.uk

Software Required: 
	Foundation SAS for most of this, and the following for some of the examples
	SAS/Access for PC File formats
	Web Infrastructure Kit
	SAS/ETS
